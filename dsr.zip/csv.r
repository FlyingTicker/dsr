print(getwd())
setwd("~/dsr")

data <- read.csv("data.csv")
print(data)
