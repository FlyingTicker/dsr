print(getwd())
setwd("~/dsr")

myData = read.delim("text.txt", header = FALSE)
print(myData)
