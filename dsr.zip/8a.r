library(cluster)
set.seed(20)
irisCluster<-kmeans(iris[,3:4],3,nstart =20)
# nstart = 20. This means that R will try 20 different random starting assignments and then select the onewiththelowestwithin clustervariation.
irisCluster
