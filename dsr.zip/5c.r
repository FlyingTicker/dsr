library('ggplot2')
data(iris)
str(iris)
scatter <- ggplot(data=iris, aes(x = Sepal.Length, y = Sepal.Width))+ geom_point(size=2,colour="black")+geom_point(size=1,colour="white")+geom_smooth(aes(colour="black"),method="lm")+ggtitle("Sepal Length vs Petal Length")+xlab("Sepal Length")+ ylab("Sepal Width") +ggtitle("Sepal Length vs petal Length")+xlab("Sepal Length") + ylab("Sepal Width")+ theme(legend.position = "none")

