
#install.packages("readxl")
library("readxl")
read_excel("~/dsr/product_list.xlsx")
