data(iris)
subset(iris,iris$Sepal.Length>7)
agg_mean = aggregate(iris[,1:4],by=list(iris$Species),FUN=mean)
agg_mean
agg_sum = aggregate(iris[,1:4],by=list(iris$Species),FUN=sum)
agg_sum
agg_sd = aggregate(iris[,1:4],by=list(iris$Species),FUN=sd)
agg_sd
agg_min = aggregate(iris[,1:4],by=list(iris$Species),FUN=min)
agg_min
agg_max = aggregate(iris[,1:4],by=list(iris$Species),FUN=max)
agg_max