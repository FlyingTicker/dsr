library(graphics)
v <-  c(9,13,21,8,36,22,12,41,31,33,19)


png(file = "histogram.png")


hist(v,xlab = "Weight",col = "yellow",border = "blue")


dev.off()
